# group2-capstone-project

git --help **resource for commands

Github repo created
Branches created : "Dev", "staging"